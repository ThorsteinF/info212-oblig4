from .models import Car
from .models import Customer
from rest_framework.response import Response
from .serializers import CarSerializer
from rest_framework import status
from django.http import JsonResponse
from rest_framework.decorators import api_view

@api_view(['GET'])
def get_cars(request):
    cars = Car.objects.all()
    serializer = CarSerializer(cars, many=True)
    print(serializer.data)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['POST'])
def save_car(request):
    serializer = CarSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

# Modifisert update_car
# addet: param carstatus, serializer.status (l 32) 
@api_view(['PUT'])
def update_car(request, id):
    try:
        theCar = Car.objects.get(pk=id)
    except Car.DoesNotexist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    serializer = CarSerializer(theCar, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def delete_car(request, id):
    try:
        theCar = Car.objects.get(pk=id)
    except Car.DoesNotexist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    theCar.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def order_car(request, customerid, carid):
    try:
        theCar = Car.objects.get(pk = carid)
        theCustomer = Customer.objects.get(pk = customerid)
        if theCar.status == "available":
            theCar.status = "booked"
            theCar.save()
    except theCar.DoesNotExist:
        return Response(status = status.HTTP_404_NOT_FOUND)
    return Response(status = status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def cancel_order_car(request, customerid, carid):
    try:
        theCar = Car.objects.get(pk = carid)
        theCustomer = Customer.objects.get(pk = customerid)
        if theCar.status == "booked":
            theCar.status = "available"
            theCar.save()
    except theCar.DoesNotExist:
        return Response(status = status.HTTP_404_NOT_FOUND)
    return Response(status = status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def rent_car(request, customerid, carid):
    try:
        theCar = Car.objects.get(pk = carid)
        theCustomer = Customer.objects.get(pk = customerid)
        if theCar.status == "booked":
            theCar.status = "rented"
            theCar.save()
    except theCar.DoesNotExist:
        return Response(status = status.HTTP_404_NOT_FOUND)
    return Response(status = status.HTTP_204_NO_CONTENT)

@api_view(['GET'])
def return_car(request, customerid, carid):
    try:
        theCar = Car.objects.get(pk = carid)
        theCustomer = Customer.objects.get(pk = customerid)
        if theCar.status == "rented":
            theCar.status = "damaged"
            theCar.save()
    except theCar.DoesNotExist:
        return Response(status = status.HTTP_404_NOT_FOUND)
    return Response(status = status.HTTP_204_NO_CONTENT)